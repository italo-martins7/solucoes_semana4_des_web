package service;

import model.Pais;

import java.util.ArrayList;

import dao.PaisDAO;

public class PaisService {
	private PaisDAO dao;

	public PaisService() {
		dao = new PaisDAO();

	}

	public int criar(Pais pais) {
		return dao.criar(pais);
	}

	public void atualizar(Pais pais) {
		dao.atualizar(pais);
	}

	public void excluir(Pais pais) {
		dao.excluir(pais);
	}

	public void excluir(int id) {
		dao.excluir(new Pais(id));
	}

	public Pais carregar(int id) {
		return dao.carregar(new Pais(id));
	}

	public Pais carregar(Pais pais) {
		return dao.carregar(pais);
	}

	public Pais MaiorPop() {
		Pais maiorPais = carregar(1);
		ArrayList<Pais> paises = dao.carregarLista();

		for (Pais pais : paises) {
			if (pais.getPopulacao() > maiorPais.getPopulacao()) {
				maiorPais = pais;
			}
		}
		return maiorPais;

	}
	public Pais MenorArea() {
		Pais menorArea = carregar(1);
		ArrayList<Pais> paises = dao.carregarLista();

		for (Pais pais : paises) {
			if (menorArea.getArea() < menorArea.getArea()) {
				menorArea = pais;
			}
		}
		return menorArea;

	}
}
